package io.sen;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.TreeMap;


import javax.xml.transform.stream.StreamResult;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class WebExtract {
	
	public static void main(String args[]) throws IOException, InterruptedException{
		
		ArrayList<String> aL = new ArrayList<String> ();
		TreeMap<String, String> tMap = new TreeMap<String, String>();
		
		aL.add("https://twitter.com/search?q=from%3Aharvardbiz%20since%3A2018-03-04%20until%3A2018-03-10&src=typd&lang=en");
		
//		aL.add("https://t.co/pQ7U7CqqbH");
//		aL.add("https://t.co/qLNbUeSqrw");
//		aL.add("https://t.co/1HC9jUHx7y");
//		aL.add("https://t.co/3TnlZLmgzb");
//		aL.add("https://t.co/qrNJYMgrJ0");
//		aL.add("https://t.co/iOXVIwhov7");
//		aL.add("https://t.co/6RiMUhCvRT");
//		aL.add("https://t.co/BgPsfrbjEd");
//		aL.add("https://t.co/Ir9NoCbZA3");
//		aL.add("https://t.co/iFmv0huCB4");
		
		String title = "";
		
		String URL = "";
		
		for (String object: aL) {
			
			URL = object;
			
			String body = "";
			
		    System.out.println(URL);
		    
		    while (object.startsWith("http")){
		    
	        Document doc = Jsoup.connect(object).get();
	        
	        title = doc.title();
	        
	        body = doc.html();
	        
	        object = title;
	        
	        Thread.sleep(5000);
	        
		    }
		    
		    
		    
		    if (! tMap.containsKey(title))
		    {
		    	System.out.println(URL + " ^ " + title);
		    	tMap.put(title, URL);
			    String encoding = "UTF-8";
			    FileOutputStream fos = new FileOutputStream("testTwit" + ".html");
			    OutputStreamWriter writer = new OutputStreamWriter(fos, encoding);
			    StreamResult streamResult = new StreamResult(writer);
			    writer.write(body);
			    writer.flush();
			    writer.close();
		    }
		}
		
		
        

        
    }
	
}
